import 'package:flutter/material.dart';

class AdiclubScreen extends StatelessWidget{
  const AdiclubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp();
  
}
}