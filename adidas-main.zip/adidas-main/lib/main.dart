import 'package:adidas/home_screen.dart';
import 'package:adidas/search_screen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp( HomeScreen());

}



